If you just want to start playing the game just launch the file called Capstone Parallax Paradox.exe
If you want spoilers/read the documentation keep on reading.

Parallax Paradox ReadMe

Instructions
This ReadMe includes detailed instructions on how to use and run Parallax Paradox. It covers key controls, platform requirements, limitations, known bugs, references, credits, and puzzle solutions.

Overview
Parallax Paradox is an experimental optical-illusion puzzle game where players find themselves trapped in a surreal dreamscape resembling a mysterious museum filled with impossible architecture and reality-bending exhibits. Each of the four themed exhibits contains five rooms, each challenging how players perceive and interact with space through forced perspective, portals, and 2D-to-3D transformations. The scattered digital alarm clocks repeatedly seen hint that this world is not all it seems — a subconscious trial where the only escape is to solve every puzzle before you.

Platform
Built for: Windows
Download: Click the Download Instructions button on the home page at https://y3s1-capstone-parallax-paradox.web.app/index.html, unzip the file and read the ReadMe.txt file.

Controls
W: Move forward
A: Strafe left
S: Move backwards
D: Strafe right
Space: Jump
M1/Left Click - Scale Object

Puzzle Mechanics/Features

Forced Perspective Scaling
Objects change size based on screen-space appearance when picked up/dropped.

Portals
Some objects behave as portals, allowing players to shift between different spaces/rooms.

Anamorphic 2D/3D Conversion
2D images align from certain perspectives and “become” real-world 3D objects when correctly viewed.

Pressure Pads
Classic activation mechanic, often used in combo with the other illusions to open paths or shift objects.

Core Gameplay Loop
1. Enter/Explore Chamber
Players enter a new exhibit room.

2. Observe the Environment
Players scan the room layout and potential illusion (2D art, portals, pads).

3. Experiment with Objects & Perspective
Interact with objects to test
Scaling effects via forced perspective.
Portal behavior (e.g., peek, walk through).
2D illusions (aligning images for transformation into 3D).
Pressure pads for unlocking doors.

4. Solve the Spatial Puzzle
Use one or more mechanics in combination to unlock progression.
Chambers evolve in complexity, culminating in a combination of mechanics in hybrid formats in the last level

5. Trigger Room Exit
Solving the room leads to the next room/level

6. Master the Mechanics and Advance
Final room of each level is an "infinite hallway" — a stylized escape sequence that:
Reinforces the mechanic and blends prior room elements into a final trial.
Creates narrative closure for the exhibit.
Players advance to the next thematic exhibit space and loop repeats with new mechanics layered on after clearing the infinite hallway

Simplified Loop:
Explore → Observe → Experiment → Solve → Exit → Advance

Level Structure and Themes
Level
Title
Key Mechanics
1
Artifacts Out of Scale
Forced perspective scaling, pressure pads
2
Portals Through Time
Portals, scaling, pressure pads
3
Perspective Pending
Anamorphic illusions, portals, scaling, pads
4
Everything Everywhere, Perceived All at Once
Hybrid of all mechanics remixed in higher quantities

Puzzle Solutions
Level 1 — Artifacts Out of Scale
Room 1
Use the scaling mechanic on the chess pieces to make platforms to reach the second level.
Room 2
Scale down the door blocking the path to reach the third room.
Room 3
Use the pressure pad to unlock the door.
Optionally: use scalable props to keep the door open or use them to reach the second level immediately without placing them on the pad.
Room 4
Place the scalable skull on the pressure pad to unlock the door.
Room 5 / Infinite Hallway
Use the scalable horse at the end of the hallway.
Place it on the pressure pad where the hallway begins to unlock the door.
Go through the unlocked door to advance to the next level.

Level 2 — Portals Through Time
Room 1
Go through the portal to enter the next section.
Scale down the door blocking the path.
Room 2
Use the portal to reach the next section and collect scalable props.
Bring them back to use as platforms to reach the second level.
Room 3
Use the portal to reach the second level.
Collect the scalable telephone and place it on the pressure pad to unlock the door.
Room 4
Use the portal to reach the next section.
Find the scalable CRT TV and place it on the pressure pad to unlock the door in the previous section.
Room 5 / Infinite Hallway
Two portals: one at the start, one at the end.
End portal: leads to a room with a scalable walkman.
Start portal: leads to a pressure pad.
Bring the walkman to the pad to unlock the door and progress.

Level 3 — Perspective Pending
Room 1
Use the anamorphic painting to spawn a scalable Rubik’s Cube.
Use it as a platform to reach the second level.
Room 2
Use the anamorphic painting to spawn a scalable office shelf.
Place it on the pressure pad to unlock the door.
Room 3
Use the anamorphic painting to spawn a set of portals.
Use them to proceed to the next room.
Room 4
Use the portal to reach the next section.
Spawn a scalable office monitor from the anamorphic painting.
Place it on the pressure pad to unlock the door in the previous section.
Room 5 / Infinite Hallway
Two portals: one at the start, one at the end.
End portal: leads to a scalable bucket via anamorphic painting.
Start portal: leads to a pressure pad.
Bring the bucket to the pad to unlock the door and progress.

Level 4 — Everything Everywhere, Perceived All at Once
Infinite Corridor
Player spawns facing the wrong way.
Walking forward loops infinitely.
Turn around to find a scalable door and shrink it to progress.
Room 1
Two pressure pads must be pressed to unlock the door.
Portal leads to an anamorphic painting → scalable telephone.
Place the telephone on the pad through the window.
Stand on the second pad yourself, then use the revealed prop to hold it open and advance.
Room 2
Two pressure pads to unlock the door.
Portal leads to another pad, an anamorphic painting, and a scalable office chair.
Painting spawns a scalable Rubik’s Cube.
Use one prop to open the door to the previous section, then the other to open the current door.
Room 3
Portal leads to an anamorphic painting.
Spawn a scalable office monitor and use it to reach the second level.
Place it on the pad to unlock the door in the previous section.
Room 4
Painting spawns a set of portals to the next section.
Second set of portals leads to another painting → scalable horse.
Bring it back to place on the pad in the first section to unlock the door.

Room 5 / Infinite Hallway
Two portals: start and end.
End portal: leads to a room with a painting that spawns a pressure pad.
Start portal: leads to a painting that spawns scalable chess pieces.
Place the chess piece on the spawned pad to unlock the door and finish the game.
Limitations/Bugs
Teleporting with Scalable Props
The scaling mechanic uses raycasting against a collider, while teleporters use a box collider trigger. Because of an intentional offset (to reduce clipping through walls), scalable props sometimes fail to touch the trigger and won’t teleport with the player.
Thin Wall Collisions
Walls are paper-thin. Oversized objects can phase through them, potentially soft-locking the player. (Tip: Use the Reset button in the pause menu if this happens.)
Scaling Push-Out Glitch
Scaling an object to an extreme size can physically push the player out of bounds. Occasionally, this launches you straight to the exit — technically a bug, but it doubles as a fun speedrun skip.
Portal Texture Loading Issue
A portal’s texture will not update unless both linked cameras are in line of sight (even through walls) to the main player camera. If one camera isn’t seen, the portal mesh renderer breaks and won’t display the other side.


Development
Engine: Unity
Team Roles
Lead Developer: Muhammad Farhan
Lead Designer: Jarene Goh
Lead 3D Modeller: Wee Han
Assistant 3D Modeller: Bontha John
Credits
Music and SFX taken from Pixabay
Main Menu Background Music: https://pixabay.com/music/smooth-jazz-piano-jazz-bossa-nova-cozy-caf%C3%A9-coffee-shop-music-203916/
Level 1 Background Music: https://pixabay.com/music/folk-fantasy-medieval-ambient-237371/
Level 2 Background Music: https://pixabay.com/music/video-games-8-bit-video-game-background-music-loop-water-368530/
Level 3 Background Music: https://pixabay.com/music/smooth-jazz-jazz-on-hold-call-center-elevator-music-351171/
Level 4 Background Music: https://pixabay.com/music/smooth-jazz-podcast-smooth-jazz-instrumental-music-225674/
Pressure Plate SFX: https://freesound.org/people/Wdomino/sounds/508581/
Medieval Door SFX: https://pixabay.com/sound-effects/church-door-83814/
Fire/Torch SFX: https://pixabay.com/sound-effects/fire-crackling-356123/
Retro Door SFX: https://pixabay.com/sound-effects/door-opening-353874/
Office Door SFX: https://pixabay.com/sound-effects/opening-metal-door-98518/
Office Light Hum SFX: https://pixabay.com/sound-effects/light-hum-84720/
Interactions SFX: https://pixabay.com/sound-effects/pick-92276/
Music for our trailer: https://pixabay.com/music/modern-classical-relaxing-piano-music-376369/
Font: https://www.fontspace.com/martius-font-f137510



